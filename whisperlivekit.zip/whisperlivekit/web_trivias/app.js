// Trivias STT Simple 1-channel UI with microphone selection

let currentLines = [];
let lineById = new Map();
let lastBufferTranscription = "";
let lastBufferTranslation = "";
let lastStatus = "active_transcription";

let websocket = null;
let websocketUrl = null;

let isRecording = false;
let serverUseAudioWorklet = true;

let audioContext = null;
let microphone = null;
let workletNode = null;
let recorderWorker = null;
let mediaRecorder = null;
let mediaStream = null;

let startTime = null;
let timerInterval = null;
let lastFullTranscript = "";

let configResolve = null;
let waitingForStop = false;
let userClosing = false;

// NEW: microphone selection state
let availableMics = [];
let selectedDeviceId = null;

let pendingSegmentUpdates = new Map(); // id -> last update payload

// DOM elements
const recordButton = document.getElementById("recordButton");
const liveTranscriptDiv = document.getElementById("liveTranscript");
if (liveTranscriptDiv) liveTranscriptDiv.style.whiteSpace = "pre-wrap";

const finalTranscriptDiv = document.getElementById("finalTranscript");
const connectionStatusSpan = document.getElementById("connectionStatus");
const micStatusSpan = document.getElementById("micStatus");
const modeStatusSpan = document.getElementById("modeStatus");
const asrStatusSpan = document.getElementById("asrStatus");
const timerSpan = document.getElementById("recordingTimer");
const hintText = document.getElementById("hintText");
const micSelect = document.getElementById("micSelect");

function initWebsocketUrl() {
  const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
  const host = window.location.host || "localhost:8000";
  // We gebruiken nu /ws (server heeft compat endpoint naar /asr)
  websocketUrl = `${proto}//${host}/ws`;
}

initWebsocketUrl();

function setConnectionStatus(connected) {
  if (!connectionStatusSpan) return;
  if (connected) {
    connectionStatusSpan.textContent = "Verbonden";
    connectionStatusSpan.classList.remove("status-disconnected");
    connectionStatusSpan.classList.add("status-connected");
  } else {
    connectionStatusSpan.textContent = "Niet verbonden";
    connectionStatusSpan.classList.remove("status-connected");
    connectionStatusSpan.classList.add("status-disconnected");
  }
}

function rebuildLineIndex(lines) {
  lineById = new Map();
  (lines || []).forEach((l) => {
    if (l && l.id) lineById.set(l.id, l);
  });
}

function setMicStatus(text) {
  if (micStatusSpan) micStatusSpan.textContent = text;
}

function setModeStatus(text) {
  if (modeStatusSpan) modeStatusSpan.textContent = text;
}

function setAsrStatus(text) {
  if (asrStatusSpan) asrStatusSpan.textContent = text;
}

function updateRecordButtonUI() {
  if (!recordButton) return;
  if (isRecording) {
    recordButton.textContent = "Stop";
    recordButton.classList.add("recording");
  } else {
    recordButton.textContent = "­Start";
    recordButton.classList.remove("recording");
  }
}

function updateHint() {
  if (!hintText) return;
  if (!isRecording) {
    hintText.innerHTML =
      "Klik op <strong>Start</strong> om de microfoon te activeren en audio naar de server te sturen.";
  } else {
    hintText.textContent = "Spreek rustig in. De tekst verschijnt hier live.";
  }
}

function formatTime(seconds) {
  const s = Math.max(0, Math.floor(seconds));
  const mm = String(Math.floor(s / 60)).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  return `${mm}:${ss}`;
}

function startTimer() {
  if (!timerSpan) return;
  startTime = Date.now();
  clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    const elapsed = (Date.now() - startTime) / 1000;
    timerSpan.textContent = formatTime(elapsed);
  }, 1000);
}

function resetTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
  if (timerSpan) {
    timerSpan.textContent = "00:00";
  }
}

function ensureWebSocket() {
  if (websocket && websocket.readyState === WebSocket.OPEN) {
    return Promise.resolve();
  }

  return new Promise((resolve, reject) => {
    configResolve = resolve;
    try {
      websocket = new WebSocket(websocketUrl);
    } catch (e) {
      console.error("Cannot create WebSocket:", e);
      setConnectionStatus(false);
      setAsrStatus("WebSocket-verbinding mislukt.");
      return reject(e);
    }

    websocket.onopen = () => {
      setConnectionStatus(true);
      setAsrStatus("Verbonden met STT-server, wacht op audio");
    };

    websocket.onerror = (err) => {
      console.error("WebSocket error:", err);
      setConnectionStatus(false);
      setAsrStatus("WebSocket-fout, controleer server.");
      if (configResolve) {
        const r = configResolve;
        configResolve = null;
        r(); // alsnog resolve om niet te blijven hangen
      }
    };

    websocket.onclose = () => {
      setConnectionStatus(false);
      if (isRecording) {
        isRecording = false;
        updateRecordButtonUI();
        updateHint();
      }
      websocket = null;
    };

    websocket.onmessage = (event) => {
      let data;
      try {
        data = JSON.parse(event.data);
      } catch (e) {
        console.warn("Non-JSON message:", event.data);
        return;
      }

      /* =========================
      * CONFIG (ongewijzigd)
      * ========================= */
      if (data.type === "config") {
        serverUseAudioWorklet = !!data.useAudioWorklet;
        const modeText = serverUseAudioWorklet
          ? "AudioWorklet (PCM)"
          : "MediaRecorder (WebM)";
        setModeStatus(modeText);

        if (configResolve) {
          const r = configResolve;
          configResolve = null;
          r();
        }
        return;
      }

      /* =========================
      * SEGMENT UPDATE (NIEUW)
      * ========================= */
      if (data.type === "segment_update") {
        const id = data.id;
        if (!id) return;

        let line = lineById.get(id);
        if (!line) {
          // Segment bestaat nog niet in currentLines; onthoud update tot volgende front_data
          pendingSegmentUpdates.set(id, data);
          return;
        }

        if (data.text_batch !== undefined) {
          line.text_batch = data.text_batch;
        }

        if (data.text_final !== undefined) {
          // Dit is de tekst die we daadwerkelijk tonen
          line.text = data.text_final;
        }

        if (data.state !== undefined) {
          line.state = data.state;
        }

        renderTranscript(
          currentLines,
          lastBufferTranscription,
          lastBufferTranslation,
          lastStatus
        );
        return;
      }

      /* =========================
      * FRONT DATA (volledige refresh)
      * ========================= */
      if (data.type === "front_data" || data.lines) {
        const {
          lines = [],
          buffer_transcription = "",
          buffer_translation = "",
          status = "active_transcription",
        } = data;

        currentLines = lines;
        rebuildLineIndex(currentLines);
        
        // Apply any pending segment updates now that lines exist
        for (const [pid, upd] of pendingSegmentUpdates.entries()) {
          const l = lineById.get(pid);
          if (!l) continue;

          if (upd.text_batch !== undefined) l.text_batch = upd.text_batch;
          if (upd.text_final !== undefined) l.text = upd.text_final;
          if (upd.state !== undefined) l.state = upd.state;

          pendingSegmentUpdates.delete(pid);
        }

        lastBufferTranscription = buffer_transcription;
        lastBufferTranslation = buffer_translation;
        lastStatus = status;

        renderTranscript(
          currentLines,
          buffer_transcription,
          buffer_translation,
          status
        );
        return;
      }

      /* =========================
      * FALLBACK / UNKNOWN
      * ========================= */
      console.debug("Unhandled WS message:", data);
    };

  });
}

function escapeHtml(s) {
  return String(s || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function getStartMs(item) {
  if (Number.isFinite(item?.start_ms)) return item.start_ms;
  if (Number.isFinite(item?.start)) return Math.round(item.start * 1000);
  return Number.MAX_SAFE_INTEGER; // live/buffer always last
}

function renderTranscript(lines, bufferTranscription, bufferTranslation, status) {
  if (!liveTranscriptDiv) return;

  if (status === "no_audio_detected") {
    liveTranscriptDiv.innerHTML =
      "<em>Geen audio gedetecteerd. Probeer iets dichter bij de microfoon te spreken.</em>";
    return;
  }

  const safeLines = (lines || []).filter((item) => {
    const sp = item?.speaker ?? item?.speaker_id ?? item?.spk;
    // -2 = silence segment → niet tonen
    return sp !== -2;
  });

  const htmlParts = [];

  safeLines.sort((a, b) => getStartMs(a) - getStartMs(b));

  for (const item of safeLines) {
    const rawTxt = (item?.text || "").trim();
    if (!rawTxt) continue;

    const sp = item?.speaker ?? item?.speaker_id ?? item?.spk;

    const st = (item?.state || "FINAL").toUpperCase();

    const cls = st === "LIVE" ? "seg seg-live" : "seg seg-final";


    const prefix =
      sp === undefined || sp === null || sp === "" || sp === -1
        ? ""
        : `[${escapeHtml(sp)}] `;

    // data-id is handig voor debug/inspectie
    const idAttr = item?.id ? ` data-id="${escapeHtml(item.id)}"` : "";

    htmlParts.push(
      `<div class="${cls}"${idAttr}>${prefix}${escapeHtml(rawTxt)}</div>`
    );
  }

  // Buffer transcription = lopend (provisional) → altijd LIVE styling
/*
if (bufferTranscription && bufferTranscription.trim().length > 0) {
  htmlParts.push(
    `<div class="seg seg-buffer seg-live">${escapeHtml(
      bufferTranscription.trim()
    )}</div>`
  );
}
*/

  liveTranscriptDiv.innerHTML =
    htmlParts.join("") || "Nog geen tekst ontvangen";

  // Bewaar laatste tekst voor jouw bestaande “lastFullTranscript”
// (optioneel) bufferTranslation ook uitgeschakeld
// if (
//   bufferTranslation &&
//   bufferTranslation.trim().length > 0 &&
//   finalTranscriptDiv
// ) {
//   finalTranscriptDiv.textContent = bufferTranslation.trim();
// }


  setAsrStatus("Live transcriptie actief");
}


// NEW: microfoonlijst ophalen en dropdown vullen (met dedupe)
async function refreshMicrophoneList() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;

  try {
    const devices = await navigator.mediaDevices.enumerateDevices();

    // Alleen audioinput
    const audioInputs = devices.filter((d) => d.kind === "audioinput");

    // Helper om label op te schonen
    const baseLabel = (label) =>
      (label || "")
        .replace(/^Standaard\s*-\s*/i, "")
        .replace(/^Communicatie\s*-\s*/i, "")
        .trim();

    // Dedupe: 1 per groupId / baselabel
    const byKey = new Map();
    for (const dev of audioInputs) {
      const key = dev.groupId || baseLabel(dev.label) || dev.deviceId;
      if (!byKey.has(key)) {
        byKey.set(key, dev);
      }
    }
    availableMics = Array.from(byKey.values());

    if (!micSelect) return;

    const previous = micSelect.value;
    micSelect.innerHTML = "";

    const defaultOption = document.createElement("option");
    defaultOption.value = "";
    defaultOption.textContent = "Systeemstandaard";
    micSelect.appendChild(defaultOption);

    let idx = 1;
    for (const mic of availableMics) {
      const opt = document.createElement("option");
      opt.value = mic.deviceId;
      opt.textContent = baseLabel(mic.label) || `Microfoon ${idx++}`;
      micSelect.appendChild(opt);
    }

    if (previous && [...micSelect.options].some((o) => o.value === previous)) {
      micSelect.value = previous;
      selectedDeviceId = previous || null;
    } else {
      selectedDeviceId = micSelect.value || null;
    }
  } catch (e) {
    console.warn("Cannot enumerate audio devices:", e);
  }
}


async function startRecording() {
  if (isRecording) return;

  try {
    await ensureWebSocket();
  } catch (e) {
    console.error("Cannot start recording, WebSocket not ready:", e);
    return;
  }

  try {
    const audioConstraints = selectedDeviceId
      ? { deviceId: { exact: selectedDeviceId } }
      : true;

    const stream = await navigator.mediaDevices.getUserMedia({
      audio: audioConstraints,
    });
    mediaStream = stream;
    setMicStatus("Toegang verleend");

    // Na succesvolle toegang: devices verversen (labels worden nu zichtbaar)
    refreshMicrophoneList();

    if (!audioContext) {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }

    const useWorklet = serverUseAudioWorklet && !!audioContext.audioWorklet;

    if (useWorklet) {
      await audioContext.audioWorklet.addModule("/web/pcm_worklet.js");
      const source = audioContext.createMediaStreamSource(stream);
      workletNode = new AudioWorkletNode(
        audioContext,
        "pcm-worklet-processor",
        {
          numberOfInputs: 1,
          numberOfOutputs: 0,
          channelCount: 1,
        }
      );
      source.connect(workletNode);

      recorderWorker = new Worker("/web/recorder_worker.js");
      recorderWorker.postMessage({
        command: "init",
        config: { sampleRate: audioContext.sampleRate },
      });

      recorderWorker.onmessage = (e) => {
        if (websocket && websocket.readyState === WebSocket.OPEN) {
          websocket.send(e.data.buffer);
        }
      };

      workletNode.port.onmessage = (e) => {
        const data = e.data;
        const ab = data instanceof ArrayBuffer ? data : data.buffer;
        recorderWorker.postMessage(
          {
            command: "record",
            buffer: ab,
          },
          [ab]
        );
      };

      setModeStatus("AudioWorklet (PCM)");
    } else {
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = (e) => {
        if (websocket && websocket.readyState === WebSocket.OPEN) {
          if (e.data && e.data.size > 0) {
            websocket.send(e.data);
          }
        }
      };
      mediaRecorder.start(250);
      setModeStatus("MediaRecorder (WebM)");
    }

    if (liveTranscriptDiv) {
      liveTranscriptDiv.textContent = "Luisteren spreek nu.";
    }
    setAsrStatus("Opname bezig");
    isRecording = true;
    userClosing = false;
    waitingForStop = false;
    updateRecordButtonUI();
    updateHint();
    startTimer();
  } catch (err) {
    console.error("Error starting recording:", err);
    setMicStatus("Toegang geweigerd of fout");
    setAsrStatus("Kon microfoon niet gebruiken. Controleer permissies of apparaat.");
  }
}

function cleanupAudio() {
  if (mediaRecorder) {
    try {
      mediaRecorder.stop();
    } catch (e) {}
    mediaRecorder = null;
  }

  if (recorderWorker) {
    try {
      recorderWorker.terminate();
    } catch (e) {}
    recorderWorker = null;
  }

  if (workletNode) {
    try {
      workletNode.port.onmessage = null;
    } catch (e) {}
    try {
      workletNode.disconnect();
    } catch (e) {}
    workletNode = null;
  }

  if (mediaStream) {
    try {
      mediaStream.getTracks().forEach((t) => t.stop());
    } catch (e) {}
    mediaStream = null;
  }
}

function stopRecording() {
  if (!isRecording) return;
  isRecording = false;
  userClosing = true;
  waitingForStop = true;

  cleanupAudio();
  resetTimer();
  updateRecordButtonUI();
  updateHint();

  if (websocket && websocket.readyState === WebSocket.OPEN) {
    const emptyBlob = new Blob([], { type: "audio/webm" });
    websocket.send(emptyBlob);
    setAsrStatus("Opname gestopt. Server is audio aan het afronden");
  } else {
    setAsrStatus("Opname gestopt.");
  }
}

function toggleRecording() {
  if (isRecording) {
    stopRecording();
  } else {
    startRecording();
  }
}

// Permissions & device handling
async function checkMicPermission() {
  if (!navigator.permissions || !navigator.permissions.query) {
    // Geen fancy permissions-API  toch devices proberen te halen
    refreshMicrophoneList();
    return;
  }
  try {
    const perm = await navigator.permissions.query({ name: "microphone" });
    setMicStatus(perm.state.toUpperCase());

    if (perm.state === "granted") {
      refreshMicrophoneList();
    }

    perm.onchange = () => {
      setMicStatus(perm.state.toUpperCase());
      if (perm.state === "granted") {
        refreshMicrophoneList();
      }
    };
  } catch {
    // Fallback: gewoon proberen
    refreshMicrophoneList();
  }
}

// Event wiring
if (recordButton) {
  recordButton.addEventListener("click", () => {
    toggleRecording();
  });
}

// NEW: change handler voor micSelect
if (micSelect) {
  micSelect.addEventListener("change", () => {
    selectedDeviceId = micSelect.value || null;
    if (isRecording) {
      setAsrStatus(
        "Nieuwe microfoon wordt gebruikt na stoppen en opnieuw starten."
      );
    }
  });
}

checkMicPermission();
updateRecordButtonUI();
updateHint();
setConnectionStatus(false);
setAsrStatus("Wachten op opname");
